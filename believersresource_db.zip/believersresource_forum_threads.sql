CREATE DATABASE  IF NOT EXISTS `believersresource` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `believersresource`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: believersresource
-- ------------------------------------------------------
-- Server version	5.5.8-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forum_threads`
--

DROP TABLE IF EXISTS `forum_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_forum_threads_categories` (`category_id`),
  CONSTRAINT `fk_forum_threads_categories` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_threads`
--

LOCK TABLES `forum_threads` WRITE;
/*!40000 ALTER TABLE `forum_threads` DISABLE KEYS */;
INSERT INTO `forum_threads` VALUES (1,'Forum Rules','forum-rules-1.html',12),(2,'How You Can Help Believers Resource','how-you-can-help-believers-resource-2.html',12),(3,'Profiting From The Gospel','profiting-from-the-gospel-3.html',12),(4,'Efficient Giving','efficient-giving-4.html',12),(5,'How Does The Bible Say We Should Give?','how-does-the-bible-say-we-should-give-5.html',12),(6,'Statistics On How Christians Are Giving','statistics-on-how-christians-are-giving-6.html',12),(7,'Avoiding Charity Gimmicks','avoiding-charity-gimmicks-7.html',12),(8,'Evaluating Charities','evaluating-charities-8.html',12),(9,'11 Steps To Finding A Good Charity','11-steps-to-finding-a-good-charity-9.html',12),(10,'Cross International Review?','cross-international-review-10.html',12),(12,'Why Don\'t We See Major Miracles Today?','why-dont-we-see-major-miracles-today-12.html',12),(14,'Particular Cause Or Tangible Effectiveness?','particular-cause-or-tangible-effectiveness-14.html',12),(17,'Similar But Still Fighting Why?','similar-but-still-fighting-why-17.html',12),(18,'Religious War','religious-war-18.html',12),(19,'Showing Your Faith','showing-your-faith-19.html',12),(20,'Feeding The Hungry','feeding-the-hungry-20.html',12),(21,'I\'m Looking For Good Christian Music','im-looking-for-good-christian-music-21.html',12),(22,'Burning Bush Tabernacle','burning-bush-tabernacle-22.html',12);
/*!40000 ALTER TABLE `forum_threads` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-03-20 10:58:38
