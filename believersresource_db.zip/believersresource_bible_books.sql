CREATE DATABASE  IF NOT EXISTS `believersresource` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `believersresource`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: believersresource
-- ------------------------------------------------------
-- Server version	5.5.8-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bible_books`
--

DROP TABLE IF EXISTS `bible_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bible_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `new_testament` bit(1) DEFAULT NULL,
  `abbreviations` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bible_books`
--

LOCK TABLES `bible_books` WRITE;
/*!40000 ALTER TABLE `bible_books` DISABLE KEYS */;
INSERT INTO `bible_books` VALUES (1,'Genesis','','Gen,Ge,Gn'),(2,'Exodus','','Exo,Ex,Exod'),(3,'Leviticus','','Lev,Le,Lv'),(4,'Numbers','','Num,Nu,Nm,Nb'),(5,'Deuteronomy','','Deut,Dt,De,Deu'),(6,'Joshua','','Josh,Jos,Jsh'),(7,'Judges','','Judg,Jdg,Jg,Jdgs,Jug'),(8,'Ruth','','Rth,Ru,Rut'),(9,'1 Samuel','','1 Sam,1 Sa,1Samuel,1S,I Sa,1 Sm,1Sa,I Sam,1Sam,I Samuel,1st Samuel,First Samuel'),(10,'2 Samuel','','2 Sam,2 Sa,2S,II Sa,2 Sm,2Sa,II Sam,2Sam,II Samuel,2Samuel,2nd Samuel,Second Samuel'),(11,'1 Kings','','1 Kgs,1 Ki,1K,I Kgs,1Kgs,I Ki,1Ki,I Kings,1Kings,1st Kgs,1st Kings,First Kings,First Kgs,1Kin'),(12,'2 Kings','','2 Kgs,2 Ki,2K,II Kgs,2Kgs,II Ki,2Ki,II Kings,2Kings,2nd Kgs,2nd Kings,Second Kings,Second Kgs,2Kin'),(13,'1 Chronicles','','1 Chron,1 Ch,I Ch,1Ch,1 Chr,I Chr,1Chr,I Chron,1Chron,I Chronicles,1Chronicles,1st Chronicles,First Chronicles'),(14,'2 Chronicles','','2 Chron,2 Ch,II Ch,2Ch,II Chr,2Chr,II Chron,2Chron,II Chronicles,2Chronicles,2nd Chronicles,Second Chronicles'),(15,'Ezra','','Ezr'),(16,'Nehemiah','','Neh,Ne'),(17,'Esther','','Esth,Es,Est'),(18,'Job','','Jb'),(19,'Psalms','','Pslm,Ps,Psalm,Psa,Psm,Pss'),(20,'Proverbs','','Prov,Pr,Prv,Pro'),(21,'Ecclesiastes','','Eccles,Ec,Ecc'),(22,'Song of Solomon','','Song,So,Song of Songs,SOS,Son'),(23,'Isaiah','','Isa,Is'),(24,'Jeremiah','','Jer,Je,Jr'),(25,'Lamentations','','Lam,La'),(26,'Ezekiel','','Ezek,Eze,Ezk'),(27,'Daniel','','Dan,Da,Dn'),(28,'Hosea','','Hos,Ho'),(29,'Joel','','Joe,Jl'),(30,'Amos','','Am,Amo'),(31,'Obadiah','','Obad,Ob,Oba'),(32,'Jonah','','Jnh,Jon'),(33,'Micah','','Mic'),(34,'Nahum','','Nah,Na'),(35,'Habakkuk','','Hab,Ha'),(36,'Zephaniah','','Zeph,Zep,Zp'),(37,'Haggai','','Hag,Hg'),(38,'Zechariah','','Zech,Zec,Zc'),(39,'Malachi','','Mal,Ml'),(40,'Matthew','','Matt,Mt,Mat'),(41,'Mark','','Mrk,Mk,Mr,Mak'),(42,'Luke','','Luk,Lk,Lu'),(43,'John','','Jn,Jhn,Joh'),(44,'Acts','','Ac,Act'),(45,'Romans','','Rom,Ro,Rm'),(46,'1 Corinthians','','1 Cor,1 Co,I Co,1Co,I Cor,1Cor,I Corinthians,1Corinthians,1st Corinthians,First Corinthians,1 Corin'),(47,'2 Corinthians','','2 Cor,2 Co,II Co,2Co,II Cor,2Cor,II Corinthians,2Corinthians,2nd Corinthians,Second Corinthians,2 Corin'),(48,'Galatians','','Gal,Ga'),(49,'Ephesians','','Ephes,Eph'),(50,'Philippians','','Phil,Php,Phl'),(51,'Colossians','','Col'),(52,'1 Thessalonians','','1 Thess,1 Th,I Th,1Th,I Thes,1Thes,I Thess,1Thess,I Thessalonians,1Thessalonians,1st Thessalonians,First Thessalonians,1Ts'),(53,'2 Thessalonians','','2 Thess,2 Th,II Th,2Th,II Thes,2Thes,II Thess,2Thess,II Thessalonians,2Thessalonians,2nd Thessalonians,Second Thessalonians,2Ts'),(54,'1 Timothy','','1 Tim,1 Ti,I Ti,1Ti,I Tim,1Tim,I Timothy,1Timothy,1st Timothy,First Timothy'),(55,'2 Timothy','','2 Tim,2 Ti,II Ti,2Ti,II Tim,2Tim,II Timothy,2Timothy,2nd Timothy,Second Timothy'),(56,'Titus','','Tit,Ti'),(57,'Philemon','','Philem,Phm,Phlm'),(58,'Hebrews','','Heb'),(59,'James','','Jas,Jm'),(60,'1 Peter','','1 Pet,1 Pe,I Pe,1Pe,I Pet,1Pet,I Pt,1 Pt,1Pt,I Peter,1Peter,1st Peter,First Peter'),(61,'2 Peter','','2 Pet,2 Pe,II Pe,2Pe,II Pet,2Pet,II Pt,2 Pt,2Pt,II Peter,2Peter,2nd Peter,Second Peter'),(62,'1 John','','1 Jn,I Jn,1Jn,I Jo,1Jo,I Joh,1Joh,I Jhn,1 Jhn,1Jhn,I John,1John,1st John,First John'),(63,'2 John','','2 Jn,II Jn,2Jn,II Jo,2Jo,II Joh,2Joh,II Jhn,2 Jhn,2Jhn,II John,2John,2nd John,Second John'),(64,'3 John','','3 Jn,III Jn,3Jn,III Jo,3Jo,III Joh,3Joh,III Jhn,3 Jhn,3Jhn,III John,3John,3rd John,Third John'),(65,'Jude','','Jud'),(66,'Revelation','','Rev,Re');
/*!40000 ALTER TABLE `bible_books` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-03-20 10:56:50
