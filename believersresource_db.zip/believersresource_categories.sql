CREATE DATABASE  IF NOT EXISTS `believersresource` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `believersresource`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: believersresource
-- ------------------------------------------------------
-- Server version	5.5.8-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_type` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `url` varchar(45) DEFAULT NULL,
  `description` text,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_categories_categories` (`parent_id`),
  CONSTRAINT `fk_categories_categories` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'download','Bibles','bibles.html','The word of God in multiple formats',0),(2,'download','Videos','videos.html','Downloadable Christian videos that can be used for a variety of purposes',0),(3,'download','Music','music.html','Christian music in several formats including Midi, MP3 and videos',0),(4,'download','Sunday School','sunday-school.html','Helpful resources for teaching a sunday school class',19),(5,'download','Audio Bibles','audio-bibles.html','Complete, downloadable audio Bibles in MP3 format',1),(6,'download','PDF Bibles','pdf-bibles.html','Complete Bibles translations in PDF format',1),(7,'download','Raw Data','bible-raw-data.html','The contents of multiple translations of the Bible in easily parsable raw data formats.',1),(8,'download','Other Languages','foreign-language-bibles.html','Downloadable PDF Bibles in multiple languages',6),(9,'download','Other','other.html','This category is a temporary catch-all for resources that do no belong in other categories.',0),(10,'download','Countdowns','video-countdowns.html','Video countdowns that can be shown to indicate when a service starts',2),(11,'download','Loopable Backgrounds','loopable-backgrounds.html','Loopable video backgrounds that can be used behind song lyrics and for other purposes',2),(12,'forum','General Discussion','general-discussion.html','\0',0),(13,'download','Midi','midi.html','Collections of Christian songs in midi format',3),(14,'download','Sermon Openers','semon-openers.html','Short videos that can be played before a sermon to introduce the topic',2),(15,'download','Testimonials','video-testimonials.html','Short video testimonials on a number of topics',2),(16,'download','Software','software.html','Free downloadable Christian software for desktop, mobile and web',0),(17,'download','Images','images.html','Free image collections containing Christian art',0),(19,'download','Teaching Resources','teaching-resources.html','Free downloadable Christian teaching resources',0),(20,'download','Adult Bible Study','adult-bible-study.html','Free adult Bible study resources that can be downloaded',19),(21,'download','Bible Commentaries','bible-commentaries.html','Classic commentaries on large portions of the Bible',19),(22,'download','Reading Plans','bible-reading-plans.html','Plans to help you read through the entire Bible or just part',1),(23,'download','Desktop','desktop-software.html','Desktop applications for churches and individuals',16),(24,'download','Mobile','mobile-software.html','Mobile applications for churches and individuals',16),(25,'download','Web','web-software.html','Web based applications for churches and individuals',16),(26,'download','Sermons','video-sermons.html','Downloadable video sermons and related material from various churches.',2),(27,'download','MP3','mp3-music.html','Legally downloadable Christian music in MP3 format.',3),(28,'download','Videos','music-videos.html','Downloadable Christian music videos and live performances',3);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-03-20 10:57:56
