CREATE DATABASE  IF NOT EXISTS `believersresource` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `believersresource`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: believersresource
-- ------------------------------------------------------
-- Server version	5.5.8-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `header` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Verse Links','Verse Links','verselinks.html','<div style=\"padding:0px 20px;\">    <img src=\"/images/verselinks.jpg\" align=\"right\" style=\"padding:0px 0px 10px 10px;\"  />    <p>The Verse Links plugin for WordPress looks for Bible verse references within a blog post and will link them to a site of your choice.  The plugin currently supports the following sites:</p>    <ul>  <li><a href=\"http://www.believersresource.com/\" target=\"_blank\">BelieversResource.com</a></li>  <li><a href=\"http://www.bible.cc/\" target=\"_blank\">Bible.cc</a></li>  <li><a href=\"http://www.biblegateway.com/\" target=\"_blank\">BibleGateway.com</a></li>  <li><a href=\"http://www.biblestudytools.com/\" target=\"_blank\">BibleStudyTools.com</a></li>  <li><a href=\"http://www.blueletterbible.org/\" target=\"_blank\">BlueLetterBible.org</a></li>  <li><a href=\"http://www.godvine.com/\" target=\"_blank\">GodVine.com</a></li>  <li><a href=\"http://www.scripturetext.com/\" target=\"_blank\">ScriptureText.com</a></li>  </ul>    <p>It can also easily be modified to support other sites by editing the sites.php file.  If you add support for another site, please let us know so it can be included in future versions.</p>    <p><a href=\"/content/verselinks.zip\">Download</a> the latest version.    For support with this plugin, visit the <a href=\"/forum/\">forum</a>.</p>  </div>'),(2,'About Us','About Us','about-us.html','<div style=\"padding:0px 20px;\">      <p>Believers Resource was started in 2007 and relaunched in 2011 with the goal of making quality Christian resources freely available for anyone.  We do this by creating original content and highlighting quality free content that others have made.</p>    <p>This site is largely community driven.  Any visitor to the site may submit a link to our downloads directory and it is the votes of other visitors to the site that determines how promenently each submission is displayed.  The same is true with our Bible research tool.  Anyone can suggest related topics, verses and websites for any passage in the Bible and the votes of others determine the relevancy of each submission.</p>    <p>The related passages in our Bible research tool were originally populated by crawling over 15 million web pages and looking for passage combinations that are regularly mentioned together.  The related topics were populated using a combination of the same crawling technique and data from the <a href=\"http://www.openbible.info/topics/\">Topical Bible</a> at OpenBible.info.  Both the related passages and topics continue to improve over time as visitors vote on the most relevant options.</p>    <p>We offer a <a href=\"/forum/\">forum</a> where most issues can be discussed, but if you would like to contact me privately you can do so at <a href=\"mailto:jeremy@believersresource.com\">jeremy@believersresource.com</a>.</p>      </div>');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-03-20 10:57:55
